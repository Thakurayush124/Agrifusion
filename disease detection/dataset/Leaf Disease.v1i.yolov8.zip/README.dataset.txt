# Leaf Disease > 2023-01-18 1:36pm
https://universe.roboflow.com/school-gapdh/leaf-disease-mjhm6

Provided by a Roboflow user
License: CC BY 4.0

